# Our agent against misty: belief-vs-misty-v1.6

Our agent scored **3-2-15** (wins-draws-losses) in 20 scored games: score 0.200, 95 % Wilson interval [0.081, 0.416].

| | Count |
|---|---|
| Games requested | 20 |
| Reached a result on the board (scored) | 20 |
| of these, recorded with an error after the last move | 0 |
| Stopped at the ply cap (not scored) | 0 |
| Failed before the end (not scored) | 0 |
| Never played | 0 |

| Our colour | Wins | Draws | Losses |
|---|---|---|---|
| White | 1 | 2 | 7 |
| Black | 2 | 0 | 8 |

Game ends: {'king_capture': 18, 'threefold_repetition': 2}. Length of scored games in plies: median 96, range 48 to 150.

Per-move figures cover every recorded move, moves of failed games included.

| Per move | Our agent | Misty |
|---|---|---|
| Moves recorded | 958 | 964 |
| Time in the move call, median ms | 1 | 5,466 |
| Time in the move call, mean ms | 2 | 5,703 |
| Time in the move call, 90th percentile ms | 5 | 6,673 |
| Time in the move call, maximum ms | 41 | 10,124 |
| Move calls longer than the budget | 0 | 964 |
| Move calls longer than 1.5 times the budget | 0 | 19 |
| Belief update (outside the budget), median ms | 0.0 | 0.3 |
| Belief update (outside the budget), maximum ms | 0 | 21,981 |

| Search effort (each side's own measure) | Value |
|---|---|
| Ours: solver backend | n/a |
| Ours: PCFR+ iterations this move, median | n/a |
| Ours: tree nodes, median | n/a |
| Ours: leaf calls, median | n/a |
| Ours: fallback moves (search not finished in time) | 0 (n/a of moves) |
| Ours: belief updates on a pruned belief, share | n/a |
| Misty: search iterations, median | 10,420 |
| Misty: belief size at the move, median / maximum | 588 / 16,000,000 |
| Misty: belief updates that hit its size cap | 6 |
| Misty: Stockfish leaf fallbacks | 0 |

Rule check: 1,942 positions compared between the two rule sets with no difference. Captures of a pawn that had just advanced two squares: 10 of misty's pawns (the only case where misty's observation says more than our rules would), 2 of ours.

| Game | Seed | Our colour | Outcome for us | Plies | End | Minutes |
|---|---|---|---|---|---|---|
| 1 | 1001 | white | loss | 48 | king_capture | 2.7 |
| 2 | 1002 | black | win | 150 | king_capture | 7.6 |
| 3 | 1003 | white | draw | 90 | threefold_repetition | 3.9 |
| 4 | 1004 | black | loss | 103 | king_capture | 5.7 |
| 5 | 1005 | white | loss | 124 | king_capture | 5.7 |
| 6 | 1006 | black | loss | 67 | king_capture | 3.1 |
| 7 | 1007 | white | loss | 124 | king_capture | 6.3 |
| 8 | 1008 | black | loss | 135 | king_capture | 6.5 |
| 9 | 1009 | white | draw | 111 | threefold_repetition | 5.0 |
| 10 | 1010 | black | loss | 53 | king_capture | 2.4 |
| 11 | 1011 | white | win | 137 | king_capture | 6.3 |
| 12 | 1012 | black | loss | 91 | king_capture | 4.5 |
| 13 | 1013 | white | loss | 92 | king_capture | 4.4 |
| 14 | 1014 | black | loss | 103 | king_capture | 5.9 |
| 15 | 1015 | white | loss | 80 | king_capture | 3.9 |
| 16 | 1016 | black | loss | 77 | king_capture | 3.8 |
| 17 | 1017 | white | loss | 76 | king_capture | 3.7 |
| 18 | 1018 | black | win | 102 | king_capture | 4.6 |
| 19 | 1019 | white | loss | 58 | king_capture | 2.6 |
| 20 | 1020 | black | loss | 101 | king_capture | 5.0 |
