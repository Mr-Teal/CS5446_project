# Our agent against misty: ppo-vs-misty-v1.6

Our agent scored **1-2-17** (wins-draws-losses) in 20 scored games: score 0.100, 95 % Wilson interval [0.028, 0.301].

| | Count |
|---|---|
| Games requested | 20 |
| Reached a result on the board (scored) | 20 |
| of these, recorded with an error after the last move | 0 |
| Stopped at the ply cap (not scored) | 0 |
| Failed before the end (not scored) | 0 |
| Never played | 0 |

| Our colour | Wins | Draws | Losses |
|---|---|---|---|
| White | 0 | 1 | 9 |
| Black | 1 | 1 | 8 |

Game ends: {'king_capture': 18, 'threefold_repetition': 2}. Length of scored games in plies: median 86, range 45 to 118.

Per-move figures cover every recorded move, moves of failed games included.

| Per move | Our agent | Misty |
|---|---|---|
| Moves recorded | 809 | 818 |
| Time in the move call, median ms | 2 | 5,171 |
| Time in the move call, mean ms | 2 | 5,565 |
| Time in the move call, 90th percentile ms | 3 | 6,673 |
| Time in the move call, maximum ms | 4 | 8,323 |
| Move calls longer than the budget | 0 | 818 |
| Move calls longer than 1.5 times the budget | 0 | 8 |
| Belief update (outside the budget), median ms | 0.0 | 0.2 |
| Belief update (outside the budget), maximum ms | 0 | 323 |

| Search effort (each side's own measure) | Value |
|---|---|
| Ours: solver backend | n/a |
| Ours: PCFR+ iterations this move, median | n/a |
| Ours: tree nodes, median | n/a |
| Ours: leaf calls, median | n/a |
| Ours: fallback moves (search not finished in time) | 0 (n/a of moves) |
| Ours: belief updates on a pruned belief, share | n/a |
| Misty: search iterations, median | 15,710 |
| Misty: belief size at the move, median / maximum | 147 / 875,555 |
| Misty: belief updates that hit its size cap | 0 |
| Misty: Stockfish leaf fallbacks | 0 |

Rule check: 1,647 positions compared between the two rule sets with no difference. Captures of a pawn that had just advanced two squares: 7 of misty's pawns (the only case where misty's observation says more than our rules would), 10 of ours.

| Game | Seed | Our colour | Outcome for us | Plies | End | Minutes |
|---|---|---|---|---|---|---|
| 1 | 1001 | white | loss | 74 | king_capture | 3.5 |
| 2 | 1002 | black | loss | 51 | king_capture | 2.4 |
| 3 | 1003 | white | loss | 100 | king_capture | 4.3 |
| 4 | 1004 | black | draw | 111 | threefold_repetition | 5.1 |
| 5 | 1005 | white | loss | 102 | king_capture | 5.0 |
| 6 | 1006 | black | loss | 45 | king_capture | 2.4 |
| 7 | 1007 | white | loss | 52 | king_capture | 2.5 |
| 8 | 1008 | black | loss | 87 | king_capture | 4.2 |
| 9 | 1009 | white | loss | 56 | king_capture | 2.5 |
| 10 | 1010 | black | loss | 83 | king_capture | 4.1 |
| 11 | 1011 | white | loss | 116 | king_capture | 5.4 |
| 12 | 1012 | black | loss | 97 | king_capture | 4.6 |
| 13 | 1013 | white | loss | 66 | king_capture | 2.8 |
| 14 | 1014 | black | loss | 93 | king_capture | 4.4 |
| 15 | 1015 | white | draw | 118 | threefold_repetition | 5.2 |
| 16 | 1016 | black | loss | 61 | king_capture | 2.8 |
| 17 | 1017 | white | loss | 86 | king_capture | 4.2 |
| 18 | 1018 | black | win | 88 | king_capture | 3.9 |
| 19 | 1019 | white | loss | 56 | king_capture | 2.8 |
| 20 | 1020 | black | loss | 85 | king_capture | 3.9 |
