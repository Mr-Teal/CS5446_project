"""Record actual Pixi environment versions without changing dependencies."""
import argparse
from hashlib import sha256
from importlib.metadata import PackageNotFoundError, version
import json
from pathlib import Path
import platform
import shutil

PROJECT = Path(__file__).resolve().parents[1]
OUT = PROJECT / "results/tracker-packed-integration-2026-11-07"
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("kind", choices=("runtime", "pair-c"))
args = parser.parse_args()
packages = {}
for name in ("numpy", "scipy", "pytest", "python-chess", "chess", "torch"):
    try:
        packages[name] = version(name)
    except PackageNotFoundError:
        packages[name] = None
data = {"python": platform.python_version(), "platform": platform.platform(), "packages": packages}
if args.kind == "pair-c":
    import yaml
    before = yaml.safe_load((OUT / "parent-pixi-before.lock").read_text(encoding="utf-8"))
    after = yaml.safe_load((PROJECT.parent / "pixi.lock").read_text(encoding="utf-8"))
    same = {name: before["environments"][name] == after["environments"][name]
            for name in before["environments"]}
    assert all(same.values()), same
    data["existing_parent_environments_unchanged"] = same
    data["new_environment"] = "pair-a-validation"
    for name in ("pixi.toml", "pixi.lock"):
        shutil.copyfile(PROJECT.parent / name, OUT / ("parent-" + name))
else:
    for name in ("pixi.toml", "pixi.lock"):
        path = PROJECT / "github-delivery/zs21_runtime" / name
        data[name + "_sha256"] = sha256(path.read_bytes()).hexdigest()
with (OUT / f"environment-{args.kind}.json").open("x", encoding="utf-8") as stream:
    json.dump(data, stream, indent=2)
    stream.write("\n")
print(json.dumps(data))
