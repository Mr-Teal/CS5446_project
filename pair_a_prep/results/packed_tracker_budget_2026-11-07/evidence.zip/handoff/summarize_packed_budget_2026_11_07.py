"""Verify saved packed-tracker runs and create the local engineering handoff."""
from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path
from statistics import median
import shutil
import subprocess
import xml.etree.ElementTree as ET

PROJECT = Path(__file__).resolve().parents[1]
REPO = PROJECT / "github-delivery"
OUT = PROJECT / "results/tracker-packed-integration-2026-11-07"
MIB = 1024 ** 2


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def rows(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def suite(path):
    suites = list(ET.parse(path).getroot().iter("testsuite"))
    return {key: sum(int(s.get(key, "0")) for s in suites)
            for key in ("tests", "failures", "errors", "skipped")}


def main():
    if (OUT / "verification.json").exists():
        raise RuntimeError("Refusing to overwrite final verification")
    shared, pair_c = suite(OUT / "shared-paira-v2.xml"), suite(OUT / "pair-c-v2.xml")
    assert shared == dict(tests=1001, failures=0, errors=0, skipped=0)
    assert pair_c == dict(tests=46, failures=0, errors=0, skipped=0)
    fixed = read(OUT / "fixed/summary.json")
    replay = read(OUT / "replay/summary.json")
    live = read(OUT / "matches/summary.json")
    assert len(fixed) == 12 and len(replay) == 10 and len(live["attempts"]) == 2
    for stage in ("fixed", "replay", "matches"):
        for name, expected in read(OUT / stage / "plan.json")["source_sha256"].items():
            assert digest(REPO / "pair_a_prep" / name) == expected, name
    complete_fixed = [row for row in fixed if row["outcome"] == "complete"]
    assert len({row["signature"] for row in complete_fixed}) == 1
    assert all((row["result"]["state_count"], row["result"]["retained_count"]) ==
               (197218, 4270301) for row in complete_fixed)
    integrated = [row for row in fixed if row["case"].startswith("integrated")]
    assert all(row["result"]["memory_inventory_count"] == 1 for row in integrated)
    assert all(row["structural_bytes_after_update"] >= row["owned_after_update"]["owned_bytes"] for row in fixed)
    accepted = sum(row["updates"] for row in replay)
    replay_updates = [r for game in range(10) for r in rows(OUT / f"replay/game-{game:03d}/updates.jsonl")]
    assert accepted == sum(row["error"] is None for row in replay_updates)
    assert all(row["status"] in ("complete", "failed") and row["true_path_audit"] and
               row["reference_counts_match"] for row in replay)
    assert all(r["result"]["support_complete"] and r["result"]["expansion_complete"]
               for r in replay_updates if r["error"] is None)
    historical = read(OUT / "historical-before.json")
    assert all(digest(REPO / path) == expected for path, expected in historical.items())
    assets = read(REPO / "zs21_runtime/assets.manifest.json")
    assert all(digest(REPO / path) == expected for path, expected in assets["files"].items())

    doctor_files = sorted({p.resolve() for p in (OUT / "t3").glob("test_real_windows_doctor*/doctor.json")})
    assert len(doctor_files) == 1, doctor_files
    shutil.copyfile(doctor_files[0], OUT / "doctor.json")
    assert read(OUT / "doctor.json")["status"] == "passed"
    groups = defaultdict(list)
    for row in fixed:
        groups[row["case"]].append(row)
    fixed_table = ["| Case | Complete | Median update s | Range s | Max logical MiB | Peak RSS MiB |",
                   "| --- | ---: | ---: | --- | ---: | ---: |"]
    for case, group in groups.items():
        times = [r["wall_ms"] / 1000 for r in group]
        fixed_table.append(f"| {case} | {sum(r['outcome']=='complete' for r in group)}/3 | {median(times):.3f} | "
            f"{min(times):.3f}–{max(times):.3f} | {max(r['result']['accounted_bytes'] for r in group)/MIB:.2f} | "
            f"{max(r['process_after_update']['process_peak_rss_bytes'] for r in group)/MIB:.2f} |")
    replay_table = ["| Game | Original plies | Result | Accepted updates | Failed ply | Max update s | Max combined tracking s | Peak RSS MiB |",
                    "| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: |"]
    for r in replay:
        replay_table.append(f"| {r['game']} | {r['source_plies']} | {r['status']} | {r['updates']} | {r.get('failed_ply','—')} | "
            f"{r['max_update_ms']/1000:.3f} | {r['max_combined_ms']/1000:.3f} | {r['process_peak_rss_bytes']/MIB:.2f} |")
    live_dir = OUT / "matches/15s-1024"
    updates, actions, applied = [rows(live_dir / name) for name in ("updates.jsonl", "actions.jsonl", "referee.jsonl")]
    def black_prefix(path):
        return [row for row in rows(path) if row["seed"] == 18 and row["player"] == "black"
                and row["observation"]["ply"] <= 11]
    prefix_matches = black_prefix(live_dir / "private-stream.jsonl") == black_prefix(
        PROJECT / "results/tracker-memory-2026-11-02/prefix11/private-stream.jsonl")
    assert prefix_matches, "Live prefix differs from the fixed-input comparison"
    live_table = ["| Seed | Result | Applied plies | Failed update | Max update s | Max returned whole-turn s | Peak RSS MiB |",
                  "| --- | --- | ---: | --- | ---: | ---: | ---: |"]
    live_details = []
    for attempt in live["attempts"]:
        seed = attempt["seed"]
        u = [row for row in updates if row["seed"] == seed]
        a = [row for row in actions if row["seed"] == seed]
        f = next((row for row in u if row["error"]), None)
        detail = {**attempt, "applied_plies": sum(row["seed"] == seed for row in applied),
            "max_update_ms": max(row["wall_ms"] for row in u),
            "max_returned_whole_turn_ms": max((row["whole_turn_ms"] for row in a), default=0),
            "peak_rss_bytes": max(row["process_peak_rss_bytes"] for row in u), "failed_update": f}
        live_details.append(detail)
        fail = "—" if f is None else f"{f['player']} ply{f['ply']}: {f['result']['stopped_by']}"
        live_table.append(f"| {seed} | {attempt['status']} | {detail['applied_plies']} | {fail} | "
            f"{detail['max_update_ms']/1000:.3f} | {detail['max_returned_whole_turn_ms']/1000:.3f} | "
            f"{detail['peak_rss_bytes']/MIB:.2f} |")

    report = {
        "date": "2026-11-07", "kind": "local_implementation_and_budget_validation_not_strength",
        "shared_pair_a": shared, "pair_c_separate_environment": pair_c,
        "fixed_cases": len(fixed), "complete_fixed": len(complete_fixed),
        "fixed_history_and_sample_parity": True, "fixed_inventory_count_one": True,
        "replays_complete": sum(r["status"] == "complete" for r in replay),
        "replay_accepted_updates": accepted, "replay_attempted_updates": len(replay_updates),
        "accepted_replay_counts_and_true_paths_match": True,
        "live_prefix11_matches_fixed_input": prefix_matches,
        "live": live_details, "current_assets_verified": len(assets["files"]),
        "historical_files_unchanged": len(historical),
        "source_sha256": read(OUT / "fixed/plan.json")["source_sha256"],
        "formal_batch_started": False, "remote_writes": False, "pr33_changed": False,
    }
    (OUT / "verification.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    text = f"""# Packed tracker integration and Windows runtime repair — 2026-11-07

Local branch: `pair-a/packed-tracker-budget`. Source combines main
`aac39b4b9226a46c63479b236a805f980412b61c`, PR65 `e6a5701` and PR66 `0968af3`
with the previously unpublished memory ledger. PR67 and its changed search
mechanisms are not imported. PR33 remains deferred. No GitHub push, comment,
review or merge and no formal playing-strength batch occurred.

## Implementation and verification

- The ledger inventories packed payloads directly, charges a shared key once,
  and never decodes a Board merely to measure storage. Retained states, path
  nodes/edges, temporary filter work and output replacement remain separate.
  Inventory is reused across resumes; full history support and exact-or-fail
  behavior are preserved. PR66's 16-bit counter boundary is unchanged by the
  user's explicit review decision.
- A newly built ZS21 DLL and both current manifests agree with the portability
  source. Stockfish 13 and NNUE bytes are unchanged. All 66 current assets match;
  {len(historical)} historical evidence files remain byte-identical. The real
  Windows doctor verifies the rule ABI and four single-thread SF13 workers.
- Compiler matching accepts appropriate x86/ARM target triples instead of
  treating all 64-bit hosts as x86_64. Windows was actually built and run;
  ARM/macOS architecture checks are mocked, not platform build certification.
- Shared/Pair A: **1001 passed**, zero skips, in the locked Python 3.12 runtime.
  Pair C: **46 passed**, zero skips, in a separate torch-enabled Pixi environment.
  These are separate invocations, not one combined environment or additive
  coverage with the earlier 214 focused tests. Pair C reports one upstream
  python-chess asyncio deprecation warning under Python 3.14.
- New regressions cover no-decode inventory/allocation, shared packed payload,
  current source/DLL identities, actual doctor execution, tamper/missing-file
  rejection and compiler architecture matching. The earlier ledger regressions
  continue to cover resume/output/RNG/history parity and scratch lifetime.
  `before.xml` includes both reproduced integration failures and tests for newly
  introduced helper APIs; its nine failures are not nine distinct product bugs.

The initial full-suite command omitted the documented Pair B PYTHONPATH and
failed collection. The first Pair C environment lacked pytest. These setup
failures are retained separately; the corrected invocations above passed.
`pair-a-validation` inherits the parent default environment, adding pytest and
python-chess; it does not change the locked `zs21_runtime` environment. See
[Pixi's multi-environment documentation](https://pixi.prefix.dev/latest/workspace/multi_environment/).

## Fixed Black ply11: three independent processes per configuration

The exact private prefix is the same reconstructed seed18 input used in the
November 2 study; its prefix through ply9 matches Bryan's saved fixture. Prefix
construction and post-update size diagnostics are outside the timed update.
Cases were frozen before execution; processes ran sequentially. The PR66
baseline uses its original tracker and graph. The integrated code keeps the
same transition semantics. All complete results match **4,270,301 histories,
197,218 states and the exact returned-sample signature**.

{chr(10).join(fixed_table)}

PR66's old cumulative charges exhaust 512 MiB despite much lower actual RSS.
The corrected ledger improves budget usability, not universal speed: the
unconstrained-enough PR66 single call is slightly faster on this fixture. All
integrated runs inventory once, including sliced runs. Logical charges are not
RSS or an OS memory limit; no pruning or hidden true-state injection occurs.

## Ten complete-game input replays

Frozen games 0–9, each in a new process. Limits: 15 s per tracker update,
1 GiB logical accounting per tracker, 16 s for both serial tracker updates.
This **excludes agent thought time**. Successful updates must match archived
state/history counts and pass an external true-path audit.

{chr(10).join(replay_table)}

Result: **{report['replays_complete']}/10 complete**, {accepted} accepted updates
out of {len(replay_updates)} recorded attempts. Every accepted update retains
complete support and passes both audits. Failures stop explicitly; they are
not losses/draws and are not omitted. The November 2 Board-ledger 6/10 result
remains a separate historical run, not a controlled same-session baseline.

## Live whole-turn diagnostic

The existing SF19 pilot uses seeds17/18 from the normal start, 15 s tracking,
1 GiB logical memory, a 16 s whole-turn wrapper and a 400-ply cutoff. The clock
includes both serial trackers, tracing and agent execution from referee handoff.
It is cooperative; late results are rejected, not forcibly interrupted by the
OS. This exercises the generic tracker and existing main search, not ZS21/SF13
playing strength. Private inputs, attempted actions and applied moves survive
resource failures.

{chr(10).join(live_table)}

No formal competition budget is accepted merely because a fixture or short
game passed. Use the complete attempt records when deciding the final budget.
Keep exact support versus explicit approximation and the whole-turn clock in
that decision; the current work does not silently change those policies.
The live seed18 Black private prefix through ply11 matches the fixed-input
comparison exactly. The tested 15 s/update, 1 GiB and 16 s whole-turn policy
**has not passed complete-game readiness**: two archived replays and one live
attempt still time out despite successful integration tests.

## Reproduction and evidence

Run the scripts through Pixi from the outer project directory:

```powershell
pixi run --locked -e darkchess python -X utf8 scripts/run_packed_budget_2026_11_07.py fixed
pixi run --locked -e darkchess python -X utf8 scripts/run_packed_budget_2026_11_07.py replay
pixi run --locked -e darkchess python -X utf8 scripts/run_packed_budget_2026_11_07.py matches
```

They refuse to overwrite existing stage outputs. Use a new dated output root
for a new run. Each stage's plan pins source hashes and settings; raw JSON,
JSONL, configs, logs and failures are retained in its subdirectory. The repo's
`pair_a_prep.benchmark_tracker_*` modules are the reusable CLI workers.

`before-working-tree.zip` and `.patch` preserve all previously uncommitted
work. `native-build/`, the current build record, regression XML/logs,
`doctor.json`, environment snapshots and `verification.json` support the
implementation handoff. Historical 34-game ZS21 results are unchanged.
"""
    (OUT / "README.md").write_text(text, encoding="utf-8")
    print(json.dumps({key: report[key] for key in ("shared_pair_a", "pair_c_separate_environment",
        "replays_complete", "replay_accepted_updates", "replay_attempted_updates", "live")}), flush=True)


if __name__ == "__main__":
    main()
