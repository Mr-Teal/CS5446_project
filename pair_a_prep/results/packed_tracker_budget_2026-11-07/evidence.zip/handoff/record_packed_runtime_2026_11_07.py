"""Record the newly built current Windows DLL without rewriting old evidence."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / "github-delivery"
OUT = ROOT / "results/tracker-packed-integration-2026-11-07"
CPP = "pair_a_prep/zs21/native/inference.cpp"
DLL = "pair_a_prep/zs21/native/inference.dll"
ASSETS = REPO / "zs21_runtime/assets.manifest.json"
NATIVE = REPO / "pair_a_prep/zs21/native/inference.manifest.json"
BUILD_RECORD = REPO / "zs21_runtime/builds/windows-native-2026-11-07.json"


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")


assets = json.loads(ASSETS.read_text(encoding="utf-8"))
native = json.loads(NATIVE.read_text(encoding="utf-8"))
build = json.loads((OUT / "native-build/build-manifest.json").read_text(encoding="utf-8"))
changed = [p for p, expected in assets["files"].items() if digest(REPO / p) != expected]
assert changed == [CPP], changed
assert digest(OUT / "native-build/inference.dll") == build["artifacts"]["inference.dll"]
assert digest(REPO / CPP) == next(iter(build["sources"].values()))
historical = {
    p.relative_to(REPO).as_posix(): digest(p)
    for directory in (REPO / "zs21_runtime/validation", REPO / "pair_a_prep/results")
    for p in directory.rglob("*") if p.is_file()
}
save(OUT / "historical-before.json", historical)
save(OUT / "previous-current-manifests.json", {"assets": assets, "native": native})
shutil.copyfile(REPO / DLL, OUT / "previous-inference.dll")
shutil.copyfile(OUT / "native-build/inference.dll", REPO / DLL)
record = {
    "date": "2026-11-07", "purpose": "current Windows native release identity after PR65 portability source change",
    "native_source_revision": "e6a5701f481dc4ab4710f49b7727056ec58f9b50",
    "integration_parent": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip(),
    "compiler": build["compiler"],
    "build_command": "pixi run --manifest-path zs21_runtime/pixi.toml --locked -e darkchess python -X utf8 zs21_runtime/scripts/build.py --native-only --output <fresh-build-directory>",
    "sources": {CPP: digest(REPO / CPP)}, "artifacts": {DLL: digest(REPO / DLL)},
    "environment": {p: digest(REPO / p) for p in ("zs21_runtime/pixi.toml", "zs21_runtime/pixi.lock")},
    "stockfish_binary_rebuilt": False, "historical_results_relabelled": False,
}
save(BUILD_RECORD, record)
assets["files"].update({p: digest(REPO / p) for p in (CPP, DLL)})
assets["native_build_record"] = BUILD_RECORD.relative_to(REPO).as_posix()
native.update(source_sha256=digest(REPO / CPP), dll_sha256=digest(REPO / DLL),
              compiler=build["compiler"].splitlines()[0],
              source_revision=record["native_source_revision"],
              build_record=assets["native_build_record"])
ASSETS.write_text(json.dumps(assets, indent=2) + "\n", encoding="utf-8")
NATIVE.write_text(json.dumps(native, indent=2) + "\n", encoding="utf-8")
assert all(digest(REPO / p) == expected for p, expected in assets["files"].items())
assert all(digest(REPO / p) == expected for p, expected in historical.items())
print(json.dumps({"assets_verified": len(assets["files"]), "historical_files_unchanged": len(historical),
                  "source": record["sources"], "binary": record["artifacts"]}))
