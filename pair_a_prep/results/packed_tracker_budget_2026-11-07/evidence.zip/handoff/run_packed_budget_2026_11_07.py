"""Sequential, predeclared packed-tracker budget checks; never strength scoring."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess

PROJECT = Path(__file__).resolve().parents[1]
REPO = PROJECT / "github-delivery"
OUT = PROJECT / "results/tracker-packed-integration-2026-11-07"
PREFIX = PROJECT / "results/tracker-memory-2026-11-02/prefix11/private-stream.jsonl"
NAMES = ("belief_tracker.py", "_belief_graph.py", "_belief_memory.py", "_belief_native.py",
         "evaluation_tracking.py", "evaluation_factories.py", "benchmark_tracker_policy.py",
         "benchmark_tracker_matches.py", "benchmark_tracker_budget_replay.py")


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def invoke(arguments, log, timeout):
    environment = dict(os.environ, PYTHONDONTWRITEBYTECODE="1",
                       PYTHONPATH=os.pathsep.join((str(REPO), str(REPO / "pair_b/src"))))
    command = ["pixi", "run", "--manifest-path", str(REPO / "zs21_runtime/pixi.toml"),
               "--locked", "-e", "darkchess", "python", "-X", "utf8", *arguments]
    with log.open("x", encoding="utf-8") as stream:
        result = subprocess.run(command, cwd=REPO, env=environment, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=timeout)
    return result.returncode


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("fixed", "replay", "matches"))
    args = parser.parse_args()
    directory = OUT / args.stage
    directory.mkdir(exist_ok=False)
    hashes = {name: sha256((REPO / "pair_a_prep" / name).read_bytes()).hexdigest() for name in NAMES}
    common = {"source_sha256": hashes, "pruning": False, "backend": "native",
              "sequential_fresh_processes": True, "kind": "budget_validation_not_strength"}
    if args.stage == "fixed":
        baseline = directory / "pr66-source"
        baseline.mkdir()
        for name in ("belief_tracker.py", "_belief_graph.py"):
            data = subprocess.check_output(["git", "show", "origin/review-66:pair_a_prep/" + name], cwd=REPO)
            (baseline / name).write_bytes(data)
        cases = [
            ("pr66-512", True, 15000, 15000, 512, 0),
            ("integrated-512", False, 15000, 15000, 512, 0),
            ("integrated-512-sliced", False, 250, 15000, 512, 60),
            ("pr66-reference", True, 30000, 30000, 3072, 0),
        ]
        save(directory / "plan.json", {**common, "cases": cases, "trials": 3, "ply": 11,
            "private_input_sha256": sha256(PREFIX.read_bytes()).hexdigest(),
            "baseline_head": "0968af345692fa7318b7a10959d087f427e60c6c"})
        records = []
        for trial in range(3):
            for name, before, slice_ms, total_ms, memory, resumes in cases:
                target = directory / f"{name}-{trial}.json"
                command = ["-m", "pair_a_prep.benchmark_tracker_policy", "--input", str(PREFIX),
                    "--output", str(target), "--ply", "11", "--slice-ms", str(slice_ms),
                    "--total-ms", str(total_ms), "--memory-mb", str(memory), "--max-resumes", str(resumes)]
                if before:
                    command += ["--tracker-source", str(baseline / "belief_tracker.py")]
                code = invoke(command, target.with_suffix(".log"), 120)
                if code:
                    raise RuntimeError(f"Unexpected measurement error: {name}/{trial}; see log")
                row = json.loads(target.read_text(encoding="utf-8"))
                records.append({"case": name, "trial": trial, **row})
                print(json.dumps({"case": name, "trial": trial, "outcome": row["outcome"],
                    "stop": row["policy_stop"], "wall_ms": row["wall_ms"], "calls": row["calls"]}), flush=True)
        completed = [row for row in records if row["outcome"] == "complete"]
        assert completed and len({row["signature"] for row in completed}) == 1
        assert all((row["result"]["state_count"], row["result"]["retained_count"]) ==
                   (197218, 4270301) for row in completed)
        save(directory / "summary.json", records)
    elif args.stage == "replay":
        inputs = REPO / "pair_a_prep/results/belief_tracker_2026-10-31"
        save(directory / "plan.json", {**common, "games": list(range(10)), "sample_size": 3,
            "tracker_ms": 15000, "combined_tracking_ms": 16000, "logical_mib": 1024,
            "agent_time_included": False})
        records = []
        for game in range(10):
            target = directory / f"game-{game:03d}"
            command = ["-m", "pair_a_prep.benchmark_tracker_budget_replay", "--input",
                str(inputs / f"inputs/game-{game:03d}.jsonl.gz"), "--reference",
                str(inputs / "full-games/updates.jsonl"), "--output", str(target)]
            code = invoke(command, directory / f"game-{game:03d}.log", 600)
            if not (target / "summary.json").exists():
                raise RuntimeError(f"Replay worker failed: {game}")
            row = json.loads((target / "summary.json").read_text(encoding="utf-8"))
            if row["status"] == "error":
                raise RuntimeError(f"Replay audit error: {game}")
            records.append(row)
            print(json.dumps({"exit_code": code, **row}), flush=True)
        save(directory / "summary.json", records)
    else:
        save(directory / "plan.json", {**common, "seeds": [17, 18], "games": 2,
            "sample_size": 3, "tracker_ms": 15000, "whole_turn_ms": 16000,
            "logical_mib": 1024, "max_plies": 400})
        target = directory / "15s-1024"
        command = ["-m", "pair_a_prep.benchmark_tracker_matches", "--config",
            str(REPO / "pair_a_prep/results/windows_tracker_pilot_2026-11-01/relaxed.ini"),
            "--output", str(target), "--engine",
            str(PROJECT / "sources/stockfish19/stockfish-windows-x86-64-universal.exe"),
            "--tracker-ms", "15000", "--memory-mb", "1024", "--whole-turn-ms", "16000"]
        code = invoke(command, directory / "15s-1024.log", 1200)
        attempts = [json.loads(line) for line in (target / "attempts.jsonl").read_text(encoding="utf-8").splitlines()]
        save(directory / "summary.json", {"exit_code": code, "attempts": attempts})
        print(json.dumps({"exit_code": code, "attempts": attempts}), flush=True)


if __name__ == "__main__":
    main()
