# Local implementation handoff

This package is prepared locally, not posted to GitHub. PR33 is deferred.
Final source commit: `7c6c8626b65634bd0ede68ae36376ea3e6af28b3` on `pair-a/packed-tracker-budget`.
Author and committer for our new commits are Shengxin Pei / P-S-X.

## PR65: Windows runtime

`handoff/pr65-windows-runtime.patch` applies to PR65 `e6a5701f481dc4ab4710f49b7727056ec58f9b50`. It rebuilds the
current native DLL, synchronizes both current manifests, records the new build,
adds the real doctor/manifests/tamper regressions, and corrects compiler target
matching. It preserves Stockfish 13/NNUE and historical measurements. Windows
was exercised; ARM/macOS architecture matching has mocked tests only.

The local commit is `a4c73ff939faace95c86dfc7f799a7d6b39cedbe`. Existing remote approvals/change requests
are unchanged; this package is not a re-review or merge authorization.

## PR66: packed tracker plus memory ledger

`handoff/pr66-packed-budget.patch` contains the complete unpublished ledger and
its packed-state adaptation, tests, telemetry, diagnostic workers and docs.
It applies to PR66 `0968af345692fa7318b7a10959d087f427e60c6c`, and also to the clean combination of current main
`aac39b4b9226a46c63479b236a805f980412b61c` with that PR. It does not contain PR67, pruning, counter widening,
report edits or neural training. Main already provides the newer evaluation
factory integration and should remain the integration target.

Apply each patch only to its stated source revision or a reviewed equivalent:

```text
git apply --check PATH_TO_PATCH
git apply PATH_TO_PATCH
```

The preparation verified both patches against independent temporary Git indices.
Applying both to the clean main+PR66 tree reconstructs the tested final source
tree exactly. It does not mutate the normal checkout index during that check.
Review and preserve existing local edits before any application.

## Validation and budget decision

Shared/Pair A: 1001 passes in the locked runtime; Pair C: 46 passes in the
separate torch-enabled Pixi environment. Read `README.md` for the source scopes,
setup failures and limitations. Twelve fixed ply11 trials have exact count and
sample parity. Ten archived full-game inputs yield 8 completions / 2 timeouts;
all 1075 accepted updates pass count and true-history audits. Live seeds17/18
yield one 39-ply completion and one Black-ply13 tracker timeout.

**15 s/update, 1 GiB/tracker and 16 s/whole turn are not an accepted full-game
competition budget.** The failure is now actual inference time in the measured
cases; do not replace exact beliefs with partial ones implicitly. Final match
ownership/configuration remain separate. Historical ZS21 34-game scores are
unchanged and not refreshed by this work.

## Re-run commands

From the repository root, with the project's parent Pixi workspace available:

```powershell
$env:PYTHONPATH = (Get-Location).Path + ';' + (Join-Path (Get-Location) 'pair_b/src')
pixi run --manifest-path zs21_runtime/pixi.toml --locked -e darkchess python -X utf8 -m pair_a_prep.build_belief_kernel
pixi run --manifest-path zs21_runtime/pixi.toml --locked -e darkchess python -X utf8 -m pytest -q tests pair_a_prep/tests
pixi run --manifest-path ../../pixi.toml --locked -e pair-a-validation python -X utf8 -m pytest -q pair_c/regression_tests
```

The separate `pair-a-validation` environment inherits default's dependencies
and adds pytest/python-chess. Its parent manifest/lock and actual package
versions are included. Other pre-existing parent environment lock entries are
unchanged. A recipient can use their existing torch-enabled Pixi environment
for Pair C instead; do not conflate its versions with the locked ZS21 runtime.

Raw trial plans/configs/records, regression logs/XML and the verified doctor
report are included. The `final-source` snapshot plus both patches pin the code;
`artifact-sha256.json` identifies packaged evidence bytes. Repository benchmark
workers use explicit CLI input/output arguments. For example, replace BUNDLE
and NEW_OUTPUT below with concrete local paths, retaining the PYTHONPATH above:

```powershell
pixi run --manifest-path zs21_runtime/pixi.toml --locked -e darkchess python -X utf8 -m pair_a_prep.benchmark_tracker_policy --input BUNDLE/fixed/private-input.jsonl --output NEW_OUTPUT/ply11.json --ply 11 --slice-ms 15000 --total-ms 15000 --memory-mb 512 --max-resumes 0
pixi run --manifest-path zs21_runtime/pixi.toml --locked -e darkchess python -X utf8 -m pair_a_prep.benchmark_tracker_budget_replay --input pair_a_prep/results/belief_tracker_2026-10-31/inputs/game-000.jsonl.gz --reference pair_a_prep/results/belief_tracker_2026-10-31/full-games/updates.jsonl --output NEW_OUTPUT/game-000 --tracker-ms 15000 --memory-mb 1024 --combined-ms 16000
```

Repeat replay games 000–009. For the PR66 fixed-input control, add
`--tracker-source BUNDLE/fixed/pr66-source/belief_tracker.py` and the corresponding
plan budgets. Live reproduction uses `pair_a_prep.benchmark_tracker_matches`,
the committed `windows_tracker_pilot_2026-11-01/relaxed.ini`, the same SF19
executable hash recorded in `matches/15s-1024/plan.json`, and CLI limits
`--tracker-ms 15000 --memory-mb 1024 --whole-turn-ms 16000 --max-plies 400`.
The two original seeds are 17 and 18. This does not replace the ZS21 SF13 engine.

The outer orchestration scripts retain their original project-layout constants;
copy them to that layout or adjust those constants for a separate workspace.
They refuse existing outputs and need new stage directories for a fresh run.
